import random # Imported to generate random numbers

def foo(n = 100, a = 0, b = 99):
    """
    `foo()` acccepts three parameters (arguments):
        * n: the number of random numbers to be generated
          (by default, it is 100)
        * a: starting number.
        * b: ending number.

    `foo()` returns a list of length `n` with random 
    integers randing (potentially) from a to b (both included).
        
    When we declare a function parameter with and "=", as
    in `n = 100`, this means that `100` is its *default time*.
    If the user provides another value for `n`, then, 
    will be the value of `n`. If not, then python assumes `n`
    is equal to `100`.
    """
    x = []
    for i in range(n):
        x.append(random.randint(a, b))
        """
        random.randint(a, b) returns a random *integer* between
        a and b (both inclusive).
        """
    return x

if __name__ == "__main__":
    a = foo() # (n = 100, a = 0, b = 99)
    b = foo(200) # n = 200, (a = 0, b = 99)
    c = foo(50, 10, 20) # n = 50, a = 10, b = 20
    d = foo(a = 30, b = 40, n = 10) # keyword arguments
    e = foo(40, b = 10, a = -5) # some positional, some keyword arguments
    """
    There are two ways to pass arguments in python functions:
        * By position (positional arguments), which 
          are determined by their order of appearance in 
          a function call;
        * By their name (keyword arguments), which are 
          determined by their name. So, writing a = 30, 
          means that... `a = 30`, regardless of `a` being 
          provided as a first argument.
    """
    print(f"a = {a}")
    print(f"b = {b}")
    print(f"c = {c}")
    print(f"d = {d}")
    print(f"e = {e}")