import random
import string # this is used only to import some string functionality

def bar(n = 100, a = 0, b = 99):
    letters = string.ascii_lowercase # `letters` = ['a', 'b', ..., 'z']
    x = dict() # x is initialized to an empty dictionary `x == {}`.
    # `x = dict()` is equivalent to `x = {}`.
    i = 0
    while i < n: # Repeat `n` times (?).
        key = "".join(random.choice(letters) for _ in range(5))
        """
        `"".join(<list of str>)` will concatenate (join) all 
        strings in <list of str> without any delimiter.

        `random.choice(<list>)` picks an element from <list> at random.
        
        When writing `_` as the looping variable we mean that 
        this variable is not intended to be used anywhere else
        inside the loop. We could well have written:
        ```
        "".join(random.choice(letters) for i in range(5))
        ```
        """
        if key in x.keys(): # If we generate a key we have already generated...
            continue # ...skip this iteration and jump to line 9.
        x[key] = random.randint(a, b)
        i += 1
    return x

if __name__ == "__main__":
    a = bar() # (n = 100, a = 0, b = 99)
    b = bar(200) # n = 200, (a = 0, b = 99)
    c = bar(50, 10, 20) # n = 50, a = 10, b = 20
    print(f"a = {a}")
    print(f"b = {b}")
    print(f"c = {c}")