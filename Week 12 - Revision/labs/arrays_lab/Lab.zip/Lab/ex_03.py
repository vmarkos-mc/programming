from ex_01 import foo # Import the almighty `foo` from ex_01.py

import math

def max_three(num_list):
    """Returns the three largest elements in `num_list`."""
    """
    1. Find the maximum element of the list and its position (index_1).
    2. Find the maximum element of list ingoring the element at index_1.
       Let index_2 be the position of that element.
    3. Find the maximum element of list ingoring the elements at index_1, index_2.

    For instance, for a = [5, 7, 3, 1, 8, 9, 0, 5, 2], then:
    1. max(a) = 9, at position index_1 = 5.
    2. [ignoring index_1 = 5] max(a) = 8, at position index_2 = 4.
    3. [ignoring index_1 = 5, index_2 = 4] max(a) = 7,
       at position index_3 = 1.
    4. Return: 7, 8, 9.
    """
    # Step 1. Find max(num_list)
    to_be_ignored = []
    max_1, ind_1 = constrained_max(num_list, to_be_ignored)
    # Step 2. Find max(num_list) ignoring ind_1.
    to_be_ignored.append(ind_1)
    max_2, ind_2 = constrained_max(num_list, to_be_ignored)
    # Step 3. Find max(num_list) ignoring both ind_1 and ind_2.
    to_be_ignored.append(ind_2)
    max_3, ind_3 = constrained_max(num_list, to_be_ignored)
    # Step 4. Return.
    return max_1, max_2, max_3

def constrained_max(num_list, indices):
    """
    Computes max(num_list) and its first position
    ignoring elements in `indices`.

    Both `num_list` and `indices` are assumed to be lists of
    integers.
    """
    current_max = -math.inf # math.inf = positive infinity
    # math.inf is larger than any "regular" number.
    max_index = None
    n = len(num_list)
    for i in range(n):
        if i in indices:
            continue
        if num_list[i] > current_max:
            current_max = num_list[i]
            max_index = i
    return current_max, max_index

if __name__ == "__main__":
    a = foo(20, 0, 40) # generate a random list of 20 integers.
    largest_3 = max_three(a)
    print(f"The three largest elements of list:\na = {a}\nare: \
          {", ".join([str(x) for x in largest_3])}")